#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"QMessageBox"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
   // ui->comboBox->addItem(QIcon(":/../../../Downloads/pngwing.com.png"),"mark");
     //ui->comboBox->addItem(QIcon(":/../../../Downloads/istockphoto-1250594547-1024x1024.jpg"),"john");
      //ui->comboBox->addItem(QIcon(":/../../../Downloads/istockphoto-1368454871-1024x1024.jpg"),"july");

      for(int i=0;i<10;i++)
      {
          ui->comboBox->addItem(QIcon(":/../../../Downloads/pngwing.com.png"),QString::number(i)+ "name");
      }
}

MainWindow::~MainWindow()
{
    delete ui;
}

