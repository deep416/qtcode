#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"QMessageBox"
#include"QPixmap"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
   QPixmap pix("/home/deepak/Downloads/pexels-mikhail-grigorev-4497925.jpg");
    int w=ui->label3->width();
    int h=ui->label3->height();
    ui->label3->setPixmap(pix.scaled(w,h,Qt::KeepAspectRatio));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
  QString username = ui->lineEdit->text();
  QString password = ui->lineEdit_2->text();
  if(username == "deepak" && password == "nano")
  {
      QMessageBox::information(this,"login","username and password is correct");
      hide();
      s=new secDialog(this);
      s->show();
  }
  else
  {
      QMessageBox::warning(this,"login","username and password is incorrect");
  }

}
