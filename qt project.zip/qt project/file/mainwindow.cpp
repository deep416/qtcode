#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"QFile"
#include"QTextStream"
#include"QMessageBox"
#include"QFileDialog"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QFile file("/home/deepak/Desktop/project/file/myfile.txt");
    if(!file.open(QFile::WriteOnly | QFile::Text))
    {
        QMessageBox::warning(this,"title","file not open");
    }
    QTextStream out(&file);
    QString text= ui->plainTextEdit->toPlainText();
    out<< text;
    file.flush();
    file.close();
}

void MainWindow::on_pushButton_2_clicked()
{
    QString filter = "All File(*.*);; text File (*.txt);; XML File(*.xml)";
    QString filename = QFileDialog::getOpenFileName(this,"open a file","/home/deepak",filter);
    QFile file(filename);
   // QFile file("/home/deepak/Desktop/project/file/myfile.txt");
    if(!file.open(QFile::ReadOnly | QFile::Text))
    {
        QMessageBox::warning(this,"title","file not open");
    }
    QTextStream in(&file);
    QString text= in.readAll();
    ui->plainTextEdit->setPlainText(text);
    file.close();
}
