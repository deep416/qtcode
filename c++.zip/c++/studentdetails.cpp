#include<iostream>
#include<string.h>
using namespace std;
class student
{
int sid;
char sname[30],grade[10];
float m1,m2,m3,total,avg;
public:
void getstudent()
{
cout<<"enter the roll number:"<<endl;
cin>>sid;
cin.ignore();
cout<<"enter student name:"<<endl;
cin.getline(sname,30);
cout<<"enter the math marks:"<<endl;
cin>>m1;
cout<<"enter the physics marks:"<<endl;
cin>>m2;
cout<<"enter the chemistry marks:"<<endl;
cin>>m3;
total=m1+m2+m3;
avg=total/3;
}

void findgrade()
{
if(m1<35||m2<35||m3<35)
strcpy(grade,"fail");
else if (avg>95)
strcpy(grade,"A+");
else if (avg>85)
strcpy(grade,"A");
else if(avg>75)
strcpy(grade,"B+");
else if(avg>60)
strcpy(grade,"B");
else
strcpy(grade,"C");
}

void putstudent()
{
cout<<"student ID:"<<sid<<endl;
cout<<"student name:"<<sname<<endl;
cout<<"total marks:"<<total<<endl;
cout<<"avg marks:"<<avg<<endl;
cout<<"student grade:"<<grade<<endl;
}
};

int main()
{
student s1;
s1.getstudent();
s1.findgrade();
s1.putstudent();
return 0;
}
 
