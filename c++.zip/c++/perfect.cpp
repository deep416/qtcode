#include<iostream>
using namespace std;
int main ()
{
int n,i,sum=0;
cout<<"enter any number"<<endl;
cin>>n;
for(i=1;i<=n/2;i++)
{
if(n%i==0)
sum=sum+i;
}
if(sum==n)
cout<<"perfect number"<<endl;
else
cout<<"not a perfect"<<endl;
return 0;
}

