#include<iostream>
using namespace std;
int main()
{
int x[5][5];
int r,c,i,j;
cout<<"enter the matrix size"<<endl;
cin>>r>>c;
cout<<"enter the matrix elements"<<endl;
for(i=0;i<r;i++)
{
for(j=0;j<c;j++)
cin>>x[i][j];
}
for(i=0;i<r;i++)
{
for(j=0;j<c;j++)
cout<<x[i][j]<<" ";
cout<<endl;
}
for(i=0;i<c;i++)
{
for(j=0;j<r;j++)
cout<<x[j][i]<<" ";
cout<<endl;
}
return 0;
}

