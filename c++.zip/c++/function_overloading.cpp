#include<iostream>
#include<math.h>
using namespace std;
float area(float r)
{
return (3.14*r*r);
}
float area (float l,float b)
{
return (l*b);
}
float area (float a,float b,float c)
{
float s=(a+b+c)/2;
return (sqrt(s*(s-a)*(s-b)*(s-c)));
}
int main()
{

cout<<"area of the circle:"<<area(2.8)<<endl;
cout<<"area of the rectangle"<<area(1.8,4.5)<<endl;
cout<<"area of the triangle"<<area(3.5,2.9,9.8)<<endl;
return 0;

}


