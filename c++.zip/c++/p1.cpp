#include<iostream>
using namespace std;

class father
{
public:
void fun1(){
cout<<"base"<<endl;
}
};

class son:public father
{
public:
void fun1(){
cout<<"derived"<<endl;
}
};

int main()
{
son s;
father f;
f.fun1();
s.fun1();
return 0;
}

