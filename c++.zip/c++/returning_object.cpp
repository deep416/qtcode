#include<iostream>
#include<stdlib.h>
using namespace std;

class Rational
{
int nr,dr;
public:
void getrational();
Rational addrational(Rational);
Rational subrational(Rational);
Rational mulrational(Rational);
Rational divrational(Rational);
void putrational();
};

void Rational::getrational()
{
cout<<"enter nr and dr"<<endl;
cin>>nr>>dr;
}
Rational Rational::addrational(Rational r2)
{
Rational r;
r.nr=nr*r2.dr+dr*r2.nr;
r.dr=dr*r2.dr;
return(r);
}
Rational Rational::mulrational(Rational r2)
{
Rational r;
r.nr=nr*r2.nr;
r.dr=dr*r2.dr;
return(r);
}
Rational Rational::divrational(Rational r2)
{
Rational r;
r.nr=nr*r2.dr;
r.dr=dr*r2.nr;
return(r);
}

int Gcd(int n,int m)
{
while(n!=m)
{
if(n>m)
n=n-m;
else
m=m-n;
}
return(m);
}

void Rational::putrational()
{
int res;
res=Gcd(nr,dr);
cout<<nr/res<<"/"<<dr/res<<endl;
}

int main()
{
int ch;
Rational r1,r2,r3;
char choice;
do
{
cout<<"1.addrational\n 2.mulrational\n 3.divrational\n 4.exit\n"<<endl;
cout<<"enter your choice\n";
cin>>ch;
r1.getrational();
r2.getrational();
switch(ch)
{
case 1:
r3=r1.addrational(r2);
break;
case 2:
r3=r1.mulrational(r2);
break;
case 3:
r3=r1.divrational(r2);
break;
case 4:
exit(0);
}
r3.putrational();
cout<<"do you want to continue y/n"<<endl;
cin>>choice;
}
while(choice=='y'||'Y');
return 0;
}



