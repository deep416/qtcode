#include<iostream>
using namespace std;
int main()
{
int a=10,b=20;
void arithmetic(const int &x,const int &y);
arithmetic(a,b);
return 0;
}
void arithmetic(const int &x,const int &y)
{
int c=x+y;
cout<<"c= "<<c<<endl;
}

