#include<iostream>
using namespace std;
int main()
{
int x[5][5];
int r,c,i,j,sum=0;
cout<<"enter matrix size"<<endl;
cin>>r>>c;
cout<<"enter matrix elements"<<endl;
for(i=0;i<r;i++)
{
for(j=0;j<c;j++)
cin>>x[i][j];
}
for(i=0;i<r;i++)
{
for(j=0;j<c;j++)
{
if(i==j)
sum=sum+x[i][j];
}
}
cout<<"sum of the principle diagonal is ="<<sum<<endl;
return 0;
}


