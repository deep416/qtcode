
#include<iostream>

using namespace std;
class Distance
{
int feets,inches;
public:
void getdistance();
void adddistance(Distance ,Distance);
void putdistance();
};
void Distance::getdistance()//member function
{
cout<<"enter feets and inches:"<<endl;
cin>>feets>>inches;
}
void Distance::adddistance(Distance x,Distance y)
{
feets=x.feets+y.feets;
inches=x.inches+y.inches;
feets=feets+feets/12;
inches=inches%12;
}
void Distance::putdistance()
{
cout<<"feets"<<feets<<endl;
cout<<"inches"<<inches<<endl;
}


int main()
{
Distance  d1,d2,d3;
d1.getdistance();
d2.getdistance();
d3.adddistance(d1,d2);
d3.putdistance();
return 0;
}

