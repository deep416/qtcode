#include<iostream>
using namespace std;
int main()
{
int n,r,rev=0,m;
cout<<"enter any number"<<endl;
cin>>n;
m=n;
while(n>0)
{
r=n%10;
rev=rev*10+r;
n=n/10;
}
if(rev==m)
cout<<"palindrome number"<<endl;
else
cout<<"not a palindrome"<<endl;
return 0;
}

