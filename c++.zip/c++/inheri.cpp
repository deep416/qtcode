#include<iostream>
using namespace std;

class stu
{
int id;
char name[20];
public:
virtual void fun()
{
cout<<"enter the stu id"<<endl;
cin>>id;
cout<<"enter student name"<<endl;
cin>>name;
}
public:
void putstu()
{
cout<<"id:"<<id<<endl;
cout<<"name:"<<name<<endl;
}
};

class abc:public stu
{
int a;
public:
virtual void fun1()
{
cout<<"derived"<<endl;
}
};
int main()
{
abc a;
a.fun();
a.fun1();
a.putstu();
}

