#include<iostream>

using namespace std;

class animal
{
public:
virtual void move()=0;
};

void animal::move()
{
 
cout<<"this is animal"<<endl;
}

class tiger:public animal
{
public:
void move(){
 animal:: move();
cout<<" ths is tiger"<<endl;
}
};


int main()
{

tiger t;
t.move();
return 0;
}


