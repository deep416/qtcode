#include<iostream>
using namespace std;

class yash
{
public:
yash()
{
cout << "this is constructor"<<endl;
}

~yash()
{
cout<<"this is disctructor"<<endl;
}
};

int main()
{
 yash y;
}

