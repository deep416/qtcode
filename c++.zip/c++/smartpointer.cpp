#include<iostream>
#include<memory>

void fun()
{

int *ptr= new int(15);
int x=45;
if(x==45)
return;
delete ptr;
}


int main()
{
 fun();
}

