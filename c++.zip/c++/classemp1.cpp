#include<iostream>
#include<stdlib.h>
using namespace std;
class emp
{
private:
int eid;
char ename[30];
float salary;
public:
void getemp()
{
cout<<"enter the employee id:"<<endl;
cin>>eid;
cin.ignore();
cout<<"enter employee name:"<<endl;
cin.getline(ename,30);
cout<<"enter employee salary:"<<endl;
cin>>salary;
}
void showemp()
{
cout<<"employee id:"<<eid<<endl;
cout<<"employee name:"<<ename<<endl;
cout<<"employee salary:"<<salary<<endl;
}
};


int main()
{
emp e1,e2;
e1.getemp();
e1.showemp();
e2.getemp();
e2.showemp();
return 0;
}


