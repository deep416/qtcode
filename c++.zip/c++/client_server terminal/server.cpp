#include<iostream>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<cstring>

using namespace std;

int main()
{

//create a socket
int lsocket,csocket;
lsocket = socket(AF_INET,SOCK_STREAM,0);
if (lsocket == -1)
{
cerr<<"cannot create socket";
return 0;
}
//bind the socket with ip address and port

sockaddr_in server,client;
server.sin_family =AF_INET;
server.sin_port = htons(54000);
server.sin_addr.s_addr = INADDR_ANY;
memset(server.sin_zero,8,0);

unsigned len = sizeof(sockaddr_in);

if((bind(lsocket,(sockaddr*)&server,len)) == -1)
{
cerr << "cant listen";
return 0;
}

//start listenning
if(listen(lsocket,5)== -1)
{
cerr << "cant listen";
}

//wait for connection

if((csocket = accept(lsocket,(sockaddr*)&client,&len))== -1)
{
cerr<<"cant accept";
return 0;
}
close(lsocket);

//while loop : send and recv message
char buf[4096];
string msg;
while(1)
{
memset(buf,4096,0);
int bytesReceived=recv(csocket,buf,4096,0);
if(bytesReceived > 0)
{
int sent = send(csocket,buf,bytesReceived+1,0);
cout<<"sent"<<sent<<"bytes to client"<<inet_ntoa(client.sin_addr)<<endl;
}
}

close(csocket);
return 0;
}


