#include<iostream>
using namespace std;
class BC
{
protected:
int i,j;
public:
BC(int x,int y)
{
i=x;
j=y;
}
virtual void show()
{
cout<<"i="<<i<<endl;
cout<<"j="<<j<<endl;
}
};
class DC:public BC
{
int k;
public:
DC(int a,int b,int c):BC(a,b)
{
c=k;
}
void show()
{
cout<<"k="<<k<<endl;
}
};

int main()
{
BC bobj(5,6);
BC *ptr;
ptr=&bobj;
ptr->show();
DC dobj(7,8,9);
ptr=&dobj;
ptr->show();
return 0;
}

