#include<iostream>
using namespace std;
int main()
{
int a=10,b=20;
void swap(int*,int*);
swap(&a,&b);
cout<<"a= "<<a<<endl;
cout<<"b= "<<b<<endl;
return 0;
}
void swap(int *x,int *y)
{
*x=*x+*y;
*y=*x-*y;
*x=*x-*y;
cout<<"x= "<<*x<<endl;
cout<<"y= "<<*y<<endl;
}

