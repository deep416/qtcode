
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QTableWidget> //header for the QTablewidget class - use for displaying and editing tabular data in grid format.
#include<QSqlQuery> //header for the QSqlQuery class - use executing and maipulating SQl queries on a connected database.
#include<QMessageBox> // use for displaying standard dialog boxes to show messages and get user confirmation
#include<QStandardItemModel> //user the generic model for sorting custom data in a hierarchical stucture.
#include<QInputDialog> //DISPLYING SIMPLE INPUT DIALOG BOXES TO GET USER INPUT.
#include<QSqlDatabase> //USER MANAGING CONNECTION TO A SQL database
#include<QDebug>//  out putting debug messages and information during application development

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
  /* This is the constructor of the MainWindow class.
  It takes a QWidget pointer parent as an argument.
  It also initializes the user interface (ui) by creating
  a new instance of the Ui::MainWindow class.*/

{
    ui->setupUi(this);
    /*This line sets up the user interface defined in
      the Ui::MainWindow class for the current MainWindow instance.*/

    timer = new QTimer(this);
    /*A new QTimer object named timer is created.
    this is passed as the parent object, which means MainWindow will
    take ownership of the timer object.*/
    connect(timer,SIGNAL(timeout()),this,SLOT(myfunction()));
    timer->start(1000);

    m_pClientSocket=new QTcpSocket(this);
    /* A new QTcpSocket object named m_pClientSocket
    is created, and this is passed as the parent object.    */

    ui->tableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    /*This line sets the context menu policy of the
    tableWidget to Qt::CustomContextMenu.It means that a custom context menu can be
    displayed for the tableWidget when the user requests it.  */

    connect(ui->tableWidget,SIGNAL(customContextMenuRequested(QPoint)),this,SLOT(ProvideContextMenu(QPoint)));
      /*This line connects the customContextMenuRequested(QPoint)
        signal of the tableWidget to the ProvideContextMenu(QPoint)
        slot of the current MainWindow instance.
        It means that when the user requests a context menu for the
        tableWidget, the ProvideContextMenu(QPoint) slot will be called.*/

    QStringList title;                                /*A new empty QStringList named title is created.  */
    setWindowTitle("Client side");                           /*This line sets the window title of the main window to "Info".   */
    ui->tableWidget->setColumnCount(4);               /*The tableWidget is set to have 4 columns.  */
    ui->tableWidget->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);
    ui->tableWidget->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOn);/*These lines set the vertical and horizontal scroll
                                                       bar policies of the tableWidget to always be visible. */
    title<<"Product Name"<<"Volume"<<"Market Captial"<< "Credit Rating";
    ui->tableWidget->setHorizontalHeaderLabels(title);
    ui->tableWidget->setShowGrid(true);
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

     mDatabase= QSqlDatabase::addDatabase("QSQLITE");
     /*This line creates a new instance of QSqlDatabase using the static
      function addDatabase(). It sets the database driver to "QSQLITE",
      which is used for working with SQLite databases  */

     mDatabase.setDatabaseName("/home/aditya/Desktop/QT/Desktop/DB_client_server/client_server2.db");
     if(!mDatabase.open())
         /*This code checks if the database can be opened.
          If the database fails to open, the condition !mDatabase.
          open() will be true. In that case, an error message dialog box
          is displayed using  */
     {
         QMessageBox::critical(this,"Error",mDatabase.lastError().text());
         return;
         /*QMessageBox::critical(). The error message contains
         the text of the last error that occurred during the database operation.
         Finally, the function returns, indicating that there was an error and
         the program should not continue. */
     }
     QSqlQuery qry;
     /*This line creates a new instance of QSqlQuery, which is used for
      executing SQL queries on the database. */

     qry.prepare("CREATE TABLE IF NOT EXISTS marketdb (ProductName, Volume, MarketCaptial, CreditRating)");

     /*This line prepares an SQL query to create a table named "marketdb"
      in the database, if it doesn't already exist. The table has four columns:
      "ProductName", "Volume", "MarketCapital", and "CreditRating".
      The prepare() function is used to set up the query with placeholders
      for any dynamic values */
     if(!qry.exec())
     {
         QMessageBox::critical(this,"Error",qry .lastError().text());
         return;
         /*This code executes the prepared SQL query using the exec() function.
         If the execution of the query fails, the condition !qry.exec() will
         be true. In that case, an error message dialog box is displayed using
         QMessageBox::critical(). The error message contains the text of the
         last error that occurred during the query execution. Finally, the
         function returns, indicating that there was an error and the
         program should not continue. */
     }

                        //Setting validator

     QRegExp re("^[A-Z a-z]+$");
     QRegExpValidator *validator = new QRegExpValidator(re, this);
     ui->lineEdit_ProductName->setValidator(validator);

     QRegExp re1("^([1-9][0-9]*)$");
     QRegExpValidator *validator1 = new QRegExpValidator(re1, this);
     ui->lineEdit_volume->setValidator(validator1);

     QRegExp re2("^[+]?([0-9]+([.][0-9]*)?|[.][0-9]+)$");
     QRegExpValidator *validator2 = new QRegExpValidator(re2, this);
     ui->lineEdit_Marketcaptial->setValidator(validator2);


     QRegExp re3("^[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)$");
     QRegExpValidator *validator3 = new QRegExpValidator(re3, this);
     ui->lineEdit_Creditrating->setValidator(validator3);


}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::ProvideContextMenu(const QPoint &pos)
{
    /*The code snippet you provided is a member function named ProvideContextMenu
     in the MainWindow class. It is used to handle the right-click context menu
     event on a QTableWidget and provide a "Delete" option to remove the
     selected row. */
    int row=ui->tableWidget->itemAt(pos)->row();
    QMenu submenu;
    submenu.addAction("Delete");
    QPoint item=ui->tableWidget->mapToGlobal(pos);
    QAction* rightclickitem=submenu.exec(item);
    if(rightclickitem && rightclickitem->text().contains("Delete"))
        ui->tableWidget->removeRow(row);
}


void MainWindow::on_pushButton_Add_clicked()
{
    QString Productname = ui->lineEdit_ProductName->text();
    QString vol = ui->lineEdit_volume->text();
    QString MarkCap = ui->lineEdit_Marketcaptial->text();
    QString CreditRate = ui->lineEdit_Creditrating->text();

    // Check if the product name already exists in the table
    for (int row = 0; row < ui->tableWidget->rowCount(); row++) {
        QTableWidgetItem* item = ui->tableWidget->item(row, 0);
        if (item && item->text() == Productname) {
            // Display an error message or take appropriate action
            QMessageBox::critical(this, "Duplicate Product", "Product name already exists!");
            return;
        }
    }

    // If the product name doesn't exist, add the new item to the table
    ui->tableWidget->insertRow(ui->tableWidget->rowCount());
    ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, 0, new QTableWidgetItem(Productname));
    ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, 1, new QTableWidgetItem(vol));
    ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, 2, new QTableWidgetItem(MarkCap));
    ui->tableWidget->setItem(ui->tableWidget->rowCount() - 1, 3, new QTableWidgetItem(CreditRate));
}


void MainWindow::on_pushButton_Close_clicked()
{
    /*In this example, the on_pushButton_Close_clicked function is connected to
    the clicked signal of the pushButton_Close button. When the button is
    clicked, this function will be executed. */
    close();
}



void MainWindow::on_pushButton_Update_clicked()
{
    /*In this example, the on_pushButton_Update_clicked function is connected to
     the clicked signal of the pushButton_Update button. When the button is
     clicked, this function will be executed. */

    int f1=ui->tableWidget->currentIndex().row();
    ui->tableWidget->setItem(f1,0,new QTableWidgetItem(ui->lineEdit_ProductName->text()));
    ui->tableWidget->setItem(f1,1,new QTableWidgetItem(ui->lineEdit_volume->text()));
    ui->tableWidget->setItem(f1,2,new QTableWidgetItem(ui->lineEdit_Marketcaptial->text()));
    ui->tableWidget->setItem(f1,3,new QTableWidgetItem(ui->lineEdit_Creditrating->text()));
}



void MainWindow::on_pushButton_save_clicked()
{
    /*In this example, the on_pushButton_save_clicked function is connected to
     the clicked signal of the pushButton_save button. When the button is
     clicked, this function will be executed. */

     int rows = ui->tableWidget->rowCount();

     int columns = ui->tableWidget->columnCount();
     /*Saving to a CSV file: This section is commented out in the provided code.
     If you want to save the data to a CSV file, uncomment this section.
     It opens a QFile and QTextStream to write the data to the file in a
     comma-separated format. */


    QSqlQuery query;
    for(int i = 0; i < rows; i++)
    {
      query.exec("Insert into marketdb(ProductName, Volume, MarketCaptial, CreditRating) values('"+ui->tableWidget->item(i,0)->text()+"','"+ui->tableWidget->item(i,1)->text()+"','"+ui->tableWidget->item(i,2)->text()+"','"+ui->tableWidget->item(i,3)->text()+"')");
      //qDebug()<<query.lastError();
    }
    //qDebug()<<query.lastError();
}



void MainWindow::on_tableWidget_itemClicked(QTableWidgetItem *item)
{
    /*In this example, the on_tableWidget_itemClicked function is connected to
     the itemClicked signal of the tableWidget. When an item in the table is
     clicked, this function will be executed. */
    int row=item->row();
    if(row>=0)
    {
        ui->lineEdit_ProductName->setText(ui->tableWidget->model()->index(row,0).data().toString());
        ui->lineEdit_volume->setText(ui->tableWidget->model()->index(row,1).data().toString());
        ui->lineEdit_Marketcaptial->setText(ui->tableWidget->model()->index(row,2).data().toString());
        ui->lineEdit_Creditrating->setText(ui->tableWidget->model()->index(row,3).data().toString());
    }
}


void MainWindow::on_pushButton_clicked()
{         /*void MainWindow::on_pushButton_clicked(): This function is executed when a
          button named "pushButton" is clicked. It establishes a connection to a host
          using a client socket (m_pClientSocket). It retrieves the IP address and
          port number from two text edit fields (textEdit_IpAddress and
          textEdit_port) and uses them to connect to the host. It also connects
          the error signal of the client socket to the displayError slot function
          to handle socket errors. */

    m_pClientSocket->connectToHost(ui->textEdit_IpAddress->toPlainText(),quint16(ui->textEdit_port->toPlainText().toInt()));
    connect(m_pClientSocket,SIGNAL(error(QAbstractSocket::SocketError)),this,SLOT(displayError(QAbstractSocket::SocketError)));
}                                                     /* or else display errors */

void MainWindow::displayError(QAbstractSocket::SocketError socketError)
{
    switch(socketError)
    {
    case QAbstractSocket::RemoteHostClosedError:
        break;
     case QAbstractSocket::HostNotFoundError:
        QMessageBox::information(this,tr("Client"),"The host was not found PLease check host name and port settings");
        break;
    case QAbstractSocket::ConnectionRefusedError:
       QMessageBox::information(this,tr("Client"),"The connection was refused");
       break;
    default:
        QMessageBox::information(this,tr("Client"),tr("The following error occured").arg(m_pClientSocket->errorString()));
    }
}

void MainWindow::on_pushButton_SendData_clicked()
{    /*void MainWindow::on_pushButton_SendData_clicked(): This function is
     executed when a button named "pushButton_SendData" is clicked. It creates
     a new QTcpSocket object (c_socket) and connects to a specific host
     (IP address "127.0.0.1" and port number 1236). If the connection is
     successful (waitForConnected returns true within the specified timeout),
     it sets up a signal-slot connection for the disconnected signal of the
     socket and proceeds to send data to the server. It retrieves data from a
     table widget (ui->tableWidget) and constructs a string sendDatatoSocket by
     appending the data values separated by delimiters. It then writes the data
     to the socket using write and closes the socket. If the connection is not
     successful, it outputs a debug message. */

    int rows = ui->tableWidget->rowCount();
    c_socket = new QTcpSocket(this);
    c_socket->connectToHost("192.168.29.110",8080);
    if(c_socket->waitForConnected(3000))
    {
        qDebug()<<"Connected to server...";
        connect(c_socket,SIGNAL(disconnected()),this,SLOT(disconnected()));
        QString productname,volume,marketcapital,creditrating;
        QString sendDatatoSocket;
        for(int i = 0; i < rows; ++i)
        {
             productname=ui->tableWidget->item(i, 0)->text();
             volume=ui->tableWidget->item(i, 1)->text();
             marketcapital= ui->tableWidget->item(i, 2)->text();
             creditrating=ui->tableWidget->item(i, 3)->text();
             sendDatatoSocket.append(productname).append("#").append(volume).append("#").append(marketcapital).append("#").append(creditrating).append("$");
         }
        qDebug()<<"SendDatatoSocket"<<sendDatatoSocket;
        c_socket->write(sendDatatoSocket.toLocal8Bit());
        c_socket->close();
     }
    else
     qDebug()<<"Not Connected to server...";
}


void MainWindow::on_label_8_linkActivated(const QString &link)
{

}

void MainWindow::myfunction()
{   /*This function updates the text displayed in the Time12 label widget with the
    current time and date. It uses the QTime::currentTime() function to obtain
    the current time and QDate::currentDate() function to obtain the current
    date. The date is converted to a string using the toString() function, and
    the time is converted to a formatted string with hours, minutes, and
    seconds. */
    QTime time=QTime::currentTime();
    QDate date=QDate::currentDate();
    QString date_text=date.toString();
    QString time_text=time.toString();
    time_text=time.toString("hh : mm : ss");
    if((time.second()%2)==0)
    {
        time_text[3]=' ';
        time_text[8]=' ';
    }
    ui->Time12->setText(time_text+"\n"+date_text);
}



