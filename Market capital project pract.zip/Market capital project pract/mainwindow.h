#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "qtablewidget.h"
#include <QMainWindow>
#include<QtSql>
#include<QSqlDatabase>
#include<QMessageBox>
#include<QDebug>
#include<QFileInfo>
#include<QTableWidget>
#include<QTcpServer>
#include<QTcpSocket>
#include<QTimer>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class QSqlQueryModel;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    QTcpSocket *m_pClientSocket;

public slots :
    void myfunction();

private slots:

    void on_pushButton_Add_clicked();

    void on_pushButton_Close_clicked();

    void on_pushButton_Update_clicked();

    void on_pushButton_save_clicked();

    void on_tableWidget_itemClicked(QTableWidgetItem *item);

    void ProvideContextMenu(const QPoint &);

     void displayError(QAbstractSocket::SocketError socketError);

    void on_pushButton_clicked();

    void on_pushButton_SendData_clicked();

    void on_label_8_linkActivated(const QString &link);

    void on_textEditMesage_copyAvailable(bool b);

private:
    Ui::MainWindow *ui;
    QSqlDatabase mDatabase;
    QSqlQueryModel *mModel;
    QTcpSocket *c_socket;
    QTimer*timer;

};
#endif // MAINWINDOW_H


