#ifndef UDPCLIENT_H
#define UDPCLIENT_H

#include <QMainWindow>
#include <QUdpSocket>

QT_BEGIN_NAMESPACE
namespace Ui { class udpclient; }
QT_END_NAMESPACE

class udpclient : public QMainWindow
{
    Q_OBJECT

    QHostAddress sender;
    quint16 senderPort;

public:
    udpclient(QWidget *parent = nullptr);
    ~udpclient();
public slots :
    void readPendingDatagrams();
private:
    Ui::udpclient *ui;
    QUdpSocket *socketclient;
};
#endif // UDPCLIENT_H
