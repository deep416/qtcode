#include "udpclient.h"
#include "ui_udpclient.h"



udpclient::udpclient(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::udpclient)
{
    ui->setupUi(this);
    socketclient=new QUdpSocket(this);
    socketclient->bind(QHostAddress::LocalHost, 1234);
    connect(socketclient,&QUdpSocket::readyRead,this,&udpclient::readPendingDatagrams);
}

udpclient::~udpclient()
{
    delete ui;
}

void udpclient::readPendingDatagrams()
{
    int numberofbytes;
    QByteArray buffer;
    while (socketclient->hasPendingDatagrams()) {

        buffer.resize(socketclient->pendingDatagramSize());

        numberofbytes =   socketclient->readDatagram(buffer.data(), buffer.size(),&sender, &senderPort);
        qDebug() << "readPendingDatagrams :: " << numberofbytes << " buffer :: " << buffer;

    }

    ui->textEdit->setText(buffer);
}
