#ifndef UDPSERVER_H
#define UDPSERVER_H

#include <QMainWindow>
#include <qudpsocket.h>

QT_BEGIN_NAMESPACE
namespace Ui { class UDPServer; }
QT_END_NAMESPACE

class UDPServer : public QMainWindow
{
    Q_OBJECT
    QHostAddress sender = QHostAddress::Any;
    quint16 senderPort = 123456;

public:
    UDPServer(QWidget *parent = nullptr);
    ~UDPServer();

private slots:
    void on_pushButton_clicked();

private:
    Ui::UDPServer *ui;
    QUdpSocket *serversocket;
};
#endif // UDPSERVER_H
