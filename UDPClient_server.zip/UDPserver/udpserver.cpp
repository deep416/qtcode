#include "udpserver.h"
#include "ui_udpserver.h"

UDPServer::UDPServer(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::UDPServer)
{
    ui->setupUi(this);
    serversocket = new QUdpSocket(this);
    serversocket->bind(QHostAddress::Any,1234);

}

UDPServer::~UDPServer()
{
    delete ui;
}

void UDPServer::on_pushButton_clicked()
{
    QString word=ui->lineEdit->text();
      QByteArray buffer;
      buffer=word.toUtf8();
  int numberofbyteswritten =     serversocket->writeDatagram(buffer.data(), QHostAddress::LocalHost, 1234 );
  qDebug() << "numberofbyteswritten :: " << numberofbyteswritten;
}

