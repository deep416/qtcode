#ifndef LOGIN_H
#define LOGIN_H
#include <QMainWindow>

#include <QDialog>
#include<QtSql>
#include<QtDebug>
#include<QFileInfo>
#include<qdebug.h>


namespace Ui {
class login;
}

class login : public QDialog
{
    Q_OBJECT

public:
   QSqlDatabase mydb;
    void connClose(){
        mydb.close();
        mydb.removeDatabase(QSqlDatabase::defaultConnection);
    }
    bool connOpen(){
        mydb=QSqlDatabase::addDatabase("QSQLITE");
       mydb.setDatabaseName("/home/chandana/signup_page.db");
       if(!mydb.open()){
          qDebug()<<("failed to open the database");
       return false;
       }
       else{
         qDebug()<<("connected...");
         return true;
}
    }
    explicit login(QWidget *parent = nullptr);
    ~login();

private slots:
    void on_login_ok_clicked();

private:
    Ui::login *ui;
};

#endif // LOGIN_H
