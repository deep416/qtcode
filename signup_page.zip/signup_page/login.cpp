#include "login.h"
#include "ui_login.h"
#include "mainwindow.h"
#include<qdebug.h>
login::login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
}

login::~login()
{
    delete ui;
}

void login::on_login_ok_clicked()
{
    MainWindow conn;
    QString Username;
    QString Password;
    conn.connOpen();
    Username=ui->login_username->text();
   Password=ui->login_password->text();
   //qDebug()<<Username;
   //qDebug()<<Password;
   QSqlQuery qry;
   if(qry.exec("SELECT *FROM hh WHERE Username='"+Username+"' and  Password='"+Password+"' "))
   {
    // ui->display->setText("correct password and username");
     int count=0;
     while(qry.next()){
         count++;
     }
     if(count==1){
         ui->display->setText("username and password is correct");
     }
     if(count<1){
         ui->display->setText("username and password is not correct");
      // close();
    }
 }
}


