#ifndef DIALOG_H
#define DIALOG_H
#include <QMainWindow>
#include <QDialog>
#include<QtSql>
#include<QtDebug>
#include<QFileInfo>
namespace Ui {
class Dialog;
}
class Dialog : public QDialog
{
    Q_OBJECT
public:
    QSqlDatabase mydb;
    void connClose()
    {
        mydb.close();
        mydb.removeDatabase(QSqlDatabase::defaultConnection);
    }
    bool connOpen(){
        mydb=QSqlDatabase::addDatabase("QSQLITE");
       mydb.setDatabaseName("/home/chandana/signup_page.db");
       if(!mydb.open()){
          qDebug()<<("failed to open the database");
       return false;
       }
       else{
         qDebug()<<("connected...");
         return true;
}
    }
    int age(const QDate &birthday);

    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Dialog *ui;

};

#endif // DIALOG_H
