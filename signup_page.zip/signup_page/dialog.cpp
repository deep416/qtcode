#include "dialog.h"
#include "ui_dialog.h"
#include"mainwindow.h"
#include<QtSql>
#include<QtDebug>
#include<QFileInfo>
#include<QSqlQuery>
#include<iostream>
#include<QDateTime>
#include <chrono>
#include <ctime>
int age;
int upper=0;
int  digit=0;
int symbol=0;
int year = QDate::currentDate().year();          //to take cureent year
QDate cd = QDate::currentDate();         //The QDate::currentDate static function returns the current date.
QTime ct = QTime::currentTime();

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    QSqlDatabase mydb;
     MainWindow conn;


}


Dialog::~Dialog()
{
    delete ui;
}
void Dialog::on_pushButton_clicked()
{

    MainWindow conn;
    QString Username;
   QString Confirmpassword;
   QString Address;
    QString Password;
    QString DD ;
    QString DM ;
    QString DY;
    QString DOB;
    QString Mobileno;
    QString Gender;
    //QString DM;
    //QString DY;
    int age;
    int upper=0;
    int digit=0;
    int symbol=0,i;

    Username=ui->lineEdit_username->text();
   Password=ui->lineEdit_password->text();
   Confirmpassword=ui->lineEdit_confirmpassword->text();
   Mobileno=ui->lineEdit_mobileno->text();
   Address=ui->lineEdit_address->text();
   QString verMsg = ui->vpassword->text();
   QString validity=ui->label_age->text();
   int passwordlen=ui->lineEdit_password->text().length();
   if(!conn.connOpen())
   {
       qDebug()<<"Failed to open the database";
       return;
   }
 conn.connOpen();   //to open database;
 bool success=false;
 QSqlQuery query;
  query.prepare("INSERT INTO hh(Username,Password,Confirmpassword,Address,DD,DM,DY) VALUES (:Username,:Password,:Confirmpassword,:Address,:DD,:DM,:DY)");
  query.bindValue(":Username", Username);

    if(passwordlen<8){
       ui->vpassword->setText(verMsg + "Your password must be at least 8 characters\n");
       conn.connClose();
   }
   else if(passwordlen>16){
       ui->vpassword->setText(verMsg + "Your password exceed the length\n");       /*set the restriction for password*/
        conn.connClose();
   }
    if(Password[0].isUpper())
            upper++;
  for(i=0; i<passwordlen; i++)
   {
        if((Password[i]>=33&&Password[i]<=47)||(Password[i]>=58&&Password[i]<=64)||(Password[i]>=91&&Password[i]<=96))
           symbol++;
       else if (Password[i].isDigit())
           digit++;
   }
  if(upper<1)
  {
       ui->vpassword->setText(verMsg +  "first letter should be capital\n");
        conn.connClose();
   }
  if (digit < 1){
       ui->vpassword->setText(verMsg +  "Password must contain at least one number\n");
    conn.connClose();
   }
   if (symbol < 1){
       ui->vpassword->setText(verMsg +  "Password must contain at least one symbol\n");
        conn.connClose();
   }
    Confirmpassword=ui->lineEdit_confirmpassword->text();
    if(Password!=Confirmpassword)
    {
        ui->confirmpassword_display->setText("inccorect password");    //link between passsword and confirm password
        conn.connClose();
    }
    Mobileno=ui->lineEdit_mobileno->text();
    DD=ui->spinBox_date->text();
    DM=ui->spinBox_month->text();
    DY=ui->spinBox_year->text();
    int n = DY.toInt();
if(year-n<18)
{
  ui->label_age->setText(validity+"not eligible");           //restriction for age
  conn.connClose();

}
    if(ui->radioButton_male->isChecked())
    Gender=ui->radioButton_male->text();
    else
    Gender=ui->radioButton_female->text();
    Address=ui->lineEdit_address->text();
   query.bindValue(":Password", Password);
   query.bindValue(":Confirmpassword", Confirmpassword);
   query.bindValue(":Mobileno", Mobileno);
   query.bindValue(":DD", DD);
   query.bindValue(":DM", DM);
   query.bindValue(":DY", DY);
   query.bindValue(":Gender",Gender);
   query.bindValue(":Address",Address);
   time_t now = time(0);    // to take real time clock.....................
 char* date_time = ctime(&now);  // convert now to string form
     ui->label_time->setText( date_time);
 if(query.exec())
   {
       success = true;
       this->hide();
   }
   else
   {
        qDebug() << "addPerson error:"
       << query.lastError();
   }
}
