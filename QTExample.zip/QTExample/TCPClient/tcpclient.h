#ifndef TCPCLIENT_H
#define TCPCLIENT_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QAbstractSocket>


QT_BEGIN_NAMESPACE
namespace Ui { class TCPClient; }
QT_END_NAMESPACE

class TCPClient : public QMainWindow
{
    Q_OBJECT

public:
    TCPClient(QWidget *parent = nullptr);
    ~TCPClient();
signals:

public slots:

    void clientsocketconnected();
    void clientsocketdisconnected();
    void clientsocketbytesWritten(qint64 bytes);
    void clientsocketreadyRead();


private slots:
    void on_sendToClient_clicked();

private:
    Ui::TCPClient *ui;
     QTcpSocket *socket;
};
#endif // TCPCLIENT_H
