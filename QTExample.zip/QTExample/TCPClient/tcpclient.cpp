#include "tcpclient.h"
#include "ui_tcpclient.h"

TCPClient::TCPClient(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::TCPClient)
{
    ui->setupUi(this);
    socket = new QTcpSocket(this);
    connect(socket, SIGNAL(connected()), this, SLOT(clientsocketconnected()));
    connect(socket, SIGNAL(disconnected()), this, SLOT(clientsocketdisconnected()));
    connect(socket, SIGNAL(readyRead()), this, SLOT(clientsocketreadyRead()));
    connect(socket, SIGNAL(bytesWritten(qint64)), this, SLOT(clientsocketbytesWritten(qint64)));

    qDebug() << "Connecting,..";

    socket->connectToHost("192.168.29.24", 1234);

    if(!socket->waitForDisconnected(1000))
    {
        qDebug() << "Error: " << socket->errorString();
    }

}

TCPClient::~TCPClient()
{
    delete ui;
}

void TCPClient::clientsocketconnected()
{
    qDebug() << "Connected!";

    socket->write("Hello from client ");
}

void TCPClient::clientsocketdisconnected()
{
    qDebug() << "Disconnected!";
}

void TCPClient::clientsocketbytesWritten(qint64 bytes)
{
    qDebug() << "We wrote: " << bytes;
}

void TCPClient::clientsocketreadyRead()
{
    qDebug() << "Reading...";
     QByteArray localReadAll = socket->readAll();
     qDebug() << "Data from Sever is " << localReadAll;

     ui->textEdit->append(QString::fromStdString(localReadAll.toStdString()));
}


void TCPClient::on_sendToClient_clicked()
{
    QString inputData = ui->sendInput->text();
    qDebug() << "Input data " << inputData;
    socket->write(inputData.toLocal8Bit());
    socket->waitForBytesWritten(40000);
}

