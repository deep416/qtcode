/********************************************************************************
** Form generated from reading UI file 'serverdata.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SERVERDATA_H
#define UI_SERVERDATA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_ServerData
{
public:
    QVBoxLayout *verticalLayout;
    QTableView *tableView;
    QPushButton *pushButton_back;

    void setupUi(QDialog *ServerData)
    {
        if (ServerData->objectName().isEmpty())
            ServerData->setObjectName(QString::fromUtf8("ServerData"));
        ServerData->resize(629, 300);
        ServerData->setStyleSheet(QString::fromUtf8("background-color: rgb(237, 51, 59);"));
        verticalLayout = new QVBoxLayout(ServerData);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        tableView = new QTableView(ServerData);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setStyleSheet(QString::fromUtf8("background-color: rgb(246, 245, 244);"));

        verticalLayout->addWidget(tableView);

        pushButton_back = new QPushButton(ServerData);
        pushButton_back->setObjectName(QString::fromUtf8("pushButton_back"));
        pushButton_back->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"color: rgb(61, 56, 70);\n"
"border: none;\n"
"background-color:transparent;\n"
"border:2px solid white;\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"color:white;\n"
"border:2px solid black;\n"
"}"));

        verticalLayout->addWidget(pushButton_back);


        retranslateUi(ServerData);

        QMetaObject::connectSlotsByName(ServerData);
    } // setupUi

    void retranslateUi(QDialog *ServerData)
    {
        ServerData->setWindowTitle(QApplication::translate("ServerData", "Dialog", nullptr));
        pushButton_back->setText(QApplication::translate("ServerData", "Back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ServerData: public Ui_ServerData {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SERVERDATA_H
