/********************************************************************************
** Form generated from reading UI file 'tcpclient.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TCPCLIENT_H
#define UI_TCPCLIENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_TCPClient
{
public:
    QWidget *centralwidget;
    QTextEdit *textEdit;
    QLineEdit *sendInput;
    QPushButton *sendToClient;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *TCPClient)
    {
        if (TCPClient->objectName().isEmpty())
            TCPClient->setObjectName(QString::fromUtf8("TCPClient"));
        TCPClient->resize(800, 600);
        centralwidget = new QWidget(TCPClient);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        textEdit = new QTextEdit(centralwidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(40, 140, 301, 241));
        sendInput = new QLineEdit(centralwidget);
        sendInput->setObjectName(QString::fromUtf8("sendInput"));
        sendInput->setGeometry(QRect(390, 320, 171, 41));
        sendToClient = new QPushButton(centralwidget);
        sendToClient->setObjectName(QString::fromUtf8("sendToClient"));
        sendToClient->setGeometry(QRect(420, 430, 111, 31));
        TCPClient->setCentralWidget(centralwidget);
        menubar = new QMenuBar(TCPClient);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 22));
        TCPClient->setMenuBar(menubar);
        statusbar = new QStatusBar(TCPClient);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        TCPClient->setStatusBar(statusbar);

        retranslateUi(TCPClient);

        QMetaObject::connectSlotsByName(TCPClient);
    } // setupUi

    void retranslateUi(QMainWindow *TCPClient)
    {
        TCPClient->setWindowTitle(QApplication::translate("TCPClient", "TCPClient", nullptr));
        sendToClient->setText(QApplication::translate("TCPClient", "Send", nullptr));
    } // retranslateUi

};

namespace Ui {
    class TCPClient: public Ui_TCPClient {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TCPCLIENT_H
