#ifndef TCPSERVER_H
#define TCPSERVER_H

#include <QMainWindow>
#include <QTcpServer>
#include <QTcpSocket>
QT_BEGIN_NAMESPACE
namespace Ui { class TCPServer; }
QT_END_NAMESPACE

class TCPServer : public QMainWindow
{
    Q_OBJECT

public:
    TCPServer(QWidget *parent = nullptr);
    ~TCPServer();

public slots:
    void newConnection();

    void serversocketconnected();
    void serversocketdisconnected();
    void serversocketbytesWritten(qint64 bytes);
    void serversocketreadyRead();

private slots:
    void on_sendtoClient_clicked();

private:
    Ui::TCPServer *ui;
     QTcpServer *server;
      QTcpSocket *socket;
};
#endif // TCPSERVER_H
