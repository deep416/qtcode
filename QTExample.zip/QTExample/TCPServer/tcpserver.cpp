#include "tcpserver.h"
#include "ui_tcpserver.h"
#include <QStandardItem>
#include <QStandardItemModel>

TCPServer::TCPServer(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::TCPServer)
{
    ui->setupUi(this);
    server = new QTcpServer(this);

    connect(server, SIGNAL(newConnection()), this, SLOT(newConnection()));

    if(!server->listen(QHostAddress::Any, 1234))
    {
        qDebug() << "Server could not start!";
    }
    else
    {
        qDebug() << "Server started!";
    }
}

TCPServer::~TCPServer()
{
    delete ui;
}

void TCPServer::newConnection()
{
   socket = server->nextPendingConnection();
   connect(socket, SIGNAL(connected()), this, SLOT(serversocketconnected()));
   connect(socket, SIGNAL(disconnected()), this, SLOT(serversocketdisconnected()));
   connect(socket, SIGNAL(readyRead()), this, SLOT(serversocketreadyRead()));
   connect(socket, SIGNAL(bytesWritten(qint64)), this, SLOT(serversocketbytesWritten(qint64)));

    socket->write("hello client\r\n");
    socket->flush();

    socket->waitForBytesWritten(3000);


}

void TCPServer::serversocketconnected()
{
    qDebug() << "Socket is connected ";
}

void TCPServer::serversocketdisconnected()
{
    qDebug() << "Socket is disconnected ";

}

void TCPServer::serversocketbytesWritten(qint64 bytes)
{
    qDebug() << "Socket is bytes writen  " << bytes;

}

void TCPServer::serversocketreadyRead()
{
    //qDebug() << "Socket is Ready to read  ";
   // QByteArray localReadAll = socket->readAll();
   // qDebug() << "Data from cleint is " << localReadAll;

   // ui->textEdit->append(QString::fromStdString(localReadAll.toStdString()));
    qDebug() << "Socket is Ready to read";
        QByteArray localReadAll = socket->readAll();
        qDebug() << "Data from client is " << localReadAll;

        // Parse the received data (assuming data is formatted as you specified)
        QString receivedData = QString::fromLocal8Bit(localReadAll);
        QStringList dataParts = receivedData.split("$", QString::SkipEmptyParts);

        // Assuming each data part contains ProductName, Volume, MarketCapital, CreditRating separated by "#"
        QStandardItemModel *model= qobject_cast<QStandardItemModel*>(ui->tableView->model());

        if (model)
        {
            foreach (const QString &dataPart, dataParts)
            {
                QStringList values = dataPart.split("#");

                if (values.size() == 4)
                {
                    QString productName= values[0];
                    QString volume = values[1];
                    QString marketCapital = values[2];
                    QString creditRating = values[3];

                    QStandardItem*item1 = new QStandardItem(productName);
                    QStandardItem *item2 = new QStandardItem(volume);
                    QStandardItem *item3 = new QStandardItem(marketCapital);
                    QStandardItem *item4 = new QStandardItem(creditRating);

                    // Add items to the model
                    QList<QStandardItem*> itemList = { item1, item2, item3, item4 };
                    model->appendRow(itemList);
                }
            }
        }
    }


    void TCPServer::on_sendtoClient_clicked()
    {
        QString dataTosend = ui->inputText->text();
        qDebug() << "Data to send from server " << dataTosend;
        socket->write(dataTosend.toLocal8Bit());
        socket->waitForBytesWritten(4000);
    }

