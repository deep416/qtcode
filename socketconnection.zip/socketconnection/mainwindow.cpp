#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    socket=new QTcpSocket(this);
    connect(socket,SIGNAL(readyRead()),this,SLOT(readyRead()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_2_clicked()
{
    ui->plainTextEdit->clear();
    socket->connectToHost("127.0.0.1",1234);
    socket->
    if(socket->waitForConnected(3000))
    {
        ui->plainTextEdit->appendPlainText("connected to host success 127.0.0.1 port 1234");
    }
    else
    {
        ui->plainTextEdit->appendPlainText("connected to host failed");
    }
}


void MainWindow::on_pushButton_clicked()
{
    if( socket->isOpen())
    {
        socket->close();
         ui->plainTextEdit->appendPlainText("connected to host closed 127.0.0.1 port 1234");

    }
}

void MainWindow::on_lineEdit_returnPressed()//writing to server
{
   char mychar[1024];
   if(socket->isWritable())
   {
       QString mystr =ui->lineEdit->text();
       memset(mychar,'\0',sizeof(mychar)+1);
       memcpy(mychar,ui->lineEdit->text().toUtf8(),mystr.length());
       socket->write(mychar);
       socket->waitForBytesWritten(1000);
       ui->plainTextEdit->appendPlainText("client send:"+QString(mychar));
       ui->lineEdit->clear();
   }
}

void MainWindow::readyRead()//receiver to server
{
    QByteArray myByte;
    myByte = socket->readAll();
    ui->plainTextEdit->appendPlainText(QString(myByte));
}
