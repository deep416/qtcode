#include<stdio.h>

void fun()
{
int a=10;
static int b=10;
++a;
++b;
printf("%d %d",a,b);
}

void main()
{
int a=100;
fun();
fun();
fun();
++a;

printf("%d %d",a,b);
}

