#include<stdio.h>
void main()
{
int n,fact,sum=0,i,r,m;
printf("enter the number of terms\n");
scanf("%d",&n);
m=n;
while(n>0)
{
r=n%10;
fact=1;
for(i=0;i<=r;i++)
fact=fact*i;
sum=sum+fact;
n=n/10;
}
if(sum==m)
printf("strong number");
else
printf("not a strong");
}

