#include<stdio.h>

void main()
{
fun();
fun();
fun();
}


int fun()
{
static int x=4;
int y=5;
++x;
++y;

printf("x=:%d y=:%d ",x,y);
return 0;
}

