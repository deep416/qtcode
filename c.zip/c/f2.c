int b;
int f1()
{
printf("value is:%d",b);
}
