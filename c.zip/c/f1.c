#include<stdio.h>

int b=20;
void f1(void);

void main()
{

int  a;
f1();

}
