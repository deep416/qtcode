#include "resdialog.h"
#include "ui_resdialog.h"
#include <QPixmap>

resDialog::resDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::resDialog)
{
    ui->setupUi(this);
    //QPixmap pic("/home/vboxuser/Downloads/chess.png");
    QPixmap pic(":/img/img/CSK.jpeg");
    ui->label_pic->setPixmap(pic.scaled(300,500,Qt::KeepAspectRatioByExpanding));
}

resDialog::~resDialog()
{
    delete ui;
}
