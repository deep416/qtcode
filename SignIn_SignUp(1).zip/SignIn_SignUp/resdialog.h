#ifndef RESDIALOG_H
#define RESDIALOG_H

#include <QDialog>

namespace Ui {
class resDialog;
}

class resDialog : public QDialog
{
    Q_OBJECT

public:
    explicit resDialog(QWidget *parent = nullptr);
    ~resDialog();

private:
    Ui::resDialog *ui;
};

#endif // RESDIALOG_H
