#include "login.h"
#include "ui_login.h"
#include "mainwindow.h"
#include "resdialog.h"
#include<dialog.h>
#include<qdebug.h>
#include<QtSql>
#include<QtDebug>
#include<QSqlDatabase>
#include <QMessageBox>
#include <QCoreApplication>
#include <QProcessEnvironment>

login::login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
}

login::~login()
{
    delete ui;
}

void login::on_login_2_clicked()
{
    QString username = ui->username->text();
    QString password = ui->password->text();

    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", "MyConnect");
    db.setDatabaseName("/home/nikhil/Desktop/qt projects/SQLdata/believe.db");

    if (db.open())
    {
        QSqlQuery qry(QSqlDatabase::database("MyConnect"));

        if (qry.exec("SELECT * FROM dd WHERE username='" + username + "' and password='" + password + "'"))
        {
            int count = 0;
            while (qry.next())
            {
                count++;
            }
            if (count == 1)
            {
                qDebug() << "Login Successful";
                QMessageBox::information(this, "Login is success", "Login Successful");
                close();
                this->hide();
                resDialog res;
                res.setModal(true);
                res.exec();



            }
            else
            {
                qDebug() << "Login Failed: Invalid username or password";
                QMessageBox::information(this, "Login is not success", "Login Failed");
            }
        }
        else
        {
            qDebug() << "Query Failed: " << qry.lastError().text();
            QMessageBox::information(this, "Query Failed", "Query Failed To Execute");
        }
    }
    else
    {
        QMessageBox::information(this, "Database Failed", "Database Connection Failed");
    }
}



