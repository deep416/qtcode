#include "dialog.h"
#include "ui_dialog.h"
#include "mainwindow.h"
#include <QtSql>
#include <QtDebug>
#include <QFileInfo>
#include <QSqlQuery>
#include <iostream>
#include <QDateTime>
#include <chrono>
#include <ctime>
#include<qdebug.h>
#include <QMainWindow>
#include <QSqlDatabase>
#include <QMessageBox>
#include <QRegularExpression>

 QString username,confirmpassword,address;
QString password;
QString date;
QString month;
QString year;
QString gender;
QString phone;
int age;
int upper=0;
int digit=0;
int symbol=0;
int yea = QDate::currentDate().year();          //to take cureent year
QDate cd = QDate::currentDate();         //The QDate::currentDate static function returns the current date.
QTime ct = QTime::currentTime();


Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    QSqlDatabase database;
    ui->username->setPlaceholderText("Enter your username");
    ui->password->setPlaceholderText("Enter your password");
    ui->confirmpassword->setPlaceholderText("Enter your confirm password");
    ui->phone->setPlaceholderText("Enter your phone number");
    ui->address->setPlaceholderText("Enter your address");
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_register_2_clicked()
{
    //Connecting to SQLite
    QSqlDatabase database=QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName("/home/pra123/Desktop/QT Projects/login.db");

    if(database.open())
    {
        //Retrieve Data from input Fields
      qDebug()<<"Data base connected ";

  QString username=ui->username->text();

  // Check if the username is unique
  QSqlQuery checkQuery;
  checkQuery.prepare("SELECT * FROM login WHERE username = :username");
  checkQuery.bindValue(":username", username);
  if (checkQuery.exec() && checkQuery.next()) {
      QMessageBox::warning(this, "Username Already Exists", "Username Already Exists.Please choose a different username.");
      return;
  }

   QString password=ui->password->text();

   // Check if password meets certain criteria, such as length and complexity
   if (password.length() < 8 || !password.contains(QRegularExpression("[A-Z a-z]")) ||
   !password.contains(QRegularExpression("[0-9]")) || !password.contains(QRegularExpression("[!@#$%^&*()_+\\-={};':\"|,.<>/?]")))  {

       // Display an error message if the password is not valid
       QMessageBox::warning(this, "Invalid Password", "Please enter a password that is at least 8 characters long and contains at least one uppercase letter, one lowercase letter, one digit, and one special character.");
       return; // Stop the function execution if the password is not valid
   }


 QString confirmpassword=ui->confirmpassword->text();
 // Check if confirm password matches the original password
 if (confirmpassword != password) {
     // Display an error message if the confirm password doesn't match
     QMessageBox::warning(this, "Passwords Don't Match", "Please make sure the confirm password matches the original password.");
     return; // Stop the function execution if the confirm password doesn't match
 }



 QString phone=ui->phone->text();
 // Check if the phone number meets the constraint

     QRegularExpression phoneRegex("^[0-9]{10}$");  // Assuming a 10-digit phone number, adjust as needed
     if (!phoneRegex.match(phone).hasMatch()) {
         QMessageBox::warning(this, "Invalid Phone Number", "Please enter a valid 10-digit phone number.");
         return;  // Stop the function execution if the phone number is not valid
     }

 QString address=ui->address->text();

            if(ui->male->isChecked())
            gender=ui->male->text();
    else
    gender=ui->female->text();

    date=ui->date->text();
   month=ui->month->text();
   year=ui->year->text();

   //  QString validity=ui->label_age->text();

     int n=year.toInt();
     if(yea-n<18) {
        // ui->label_age->setText(validity+"not eligible");    //restriction for age
         QMessageBox::warning(this, "Invalid Age", "You must be atleast 18 years old to register.");
         return;
     }


   address=ui->address->text();
   //Run our insert query

   QSqlQuery qry;

   qry.prepare("INSERT INTO login (Username, Password, ConfirmPassword, phone, Address) VALUES ('"+username+"', '"+password+"', '"+confirmpassword+"', '"+phone+"', '"+address+"')");



   if(qry.exec()){
       QMessageBox::information(this,"inserted","Registered successfully");
       close();
   }else
   {
       qDebug()<<qry.lastError().text();
       QMessageBox::information(this,"Not inserted","Data is Not Inserted");
   }
    }else{
        QMessageBox::information(this,"Not connected","Database is Not connected");
    }
}








