#include "dialog_2.h"
#include "ui_dialog_2.h"
#include <QCryptographicHash>
#include <mainwindow.h>
#include <QMessageBox>

Dialog_2::Dialog_2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog_2)
{
    ui->setupUi(this);

    MainWindow conn;

    if (!conn.connOpen())
    {
        ui->label_signin->setText("Not connected to dataase");
    }

}

Dialog_2::~Dialog_2()
{
    delete ui;
}

void Dialog_2::on_pushButton_Dialog2_login_clicked()
{

    QString Loguser = ui->label_Dialog2_user->text();
    QString Logpass = ui->label_Dialog2_pass->text();

    MainWindow conn;

    if (!conn.connOpen())
    {
        qDebug()<<"Not connected to dataase";
    }
    else
    {
       qDebug()<<"connected to dataase";
    }

    (conn.connOpen());


    QSqlQuery query;
   if(query.exec("SELECT * FROM table_userinfo WHERE username = '"+Loguser+"' and password = '"+Logpass+"'"))
   {
       int cout = 0;
       while(query.next())
       {
           cout ++;
       }
       if (cout == 1)
       {
           qDebug() << "Login successful..";
           QMessageBox::information(this,"title","Login Successful");
       }
       else
       {
           qDebug() << "Login Unsuccessful..";
           QMessageBox::information(this,"title","Login Unsuccessful");
       }
   }
       else
       {
           qDebug() << "Query Failed..";
           QMessageBox::information(this,"title","Query failed to execute..");
       }
   }



