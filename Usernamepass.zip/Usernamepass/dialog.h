#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QAbstractButton>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog();

private slots:
    void on_pushButton_register_clicked();




    void on_radioButton_male_clicked();

    void on_radioButton_female_clicked();

    void on_radioButton_transmale_clicked();

    void on_comboBox_country_activated(int index);

private:
    Ui::Dialog *ui;

        bool hasLowercase(const QString &str);
        bool hasUppercase(const QString &str);
        bool hasNumericcase(const QString &str);

};

#endif // DIALOG_H
