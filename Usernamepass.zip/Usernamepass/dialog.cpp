#include "dialog.h"
#include "ui_dialog.h"
#include "mainwindow.h"
#include <QRadioButton>
#include <QButtonGroup>
#include <mainwindow.h>

QString gender;
QString Country;

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);

    for (int i = 1; i <= 31; ++i) ui->comboBox_day->addItem(QString::number(i));
    for (int i = 1; i <= 12; ++i) ui->comboBox_month->addItem(QString::number(i));
    for (int i = 1900; i <= 2023; ++i) ui->comboBox_year->addItem(QString::number(i));


    connect(ui->pushButton_register,SIGNAL(clicked()),this,SLOT(on_pushButton_register_clicked));

    connect(ui->radioButton_male,SIGNAL(clicked()),this,SLOT(on_radioButton_male_clicked()));
    connect(ui->radioButton_female,SIGNAL(clicked()),this,SLOT(on_radioButton_female_clicked()));
    connect(ui->radioButton_transmale,SIGNAL(clicked()),this,SLOT(on_radioButton_transmale_clicked()));

    connect(ui->comboBox_country,SIGNAL(activated(int)),this,SLOT(on_comboBox_country_activated(int)));

}

Dialog::~Dialog()
{
    delete ui;
}

bool Dialog::hasLowercase(const QString &str)
{
    for (QChar ch : str) {
        if (ch.isLower()) {
            return true;
        }
    }
    return false;
}

bool Dialog::hasUppercase(const QString &str)
{
    for (QChar ch : str) {
        if (ch.isUpper()) {
            return true;
        }
    }
    return false;
}

bool Dialog::hasNumericcase(const QString &str)
{
    for (QChar ch : str) {
        if (ch.isDigit()) {
            return true;
        }
    }
    return false;
}


void Dialog::on_pushButton_register_clicked()
{
    MainWindow conn;
    QString username = ui->lineEdit_username->text();
    QString password = ui->lineEdit_password->text();
    QString confirmPassword = ui->lineEdit_cpass->text();
    QString mobile = ui->lineEdit_mobile->text();
    QString address = ui->lineEdit_address->text();

    int day = ui->comboBox_day->currentText().toInt();
    int month = ui->comboBox_month->currentText().toInt();
    int year = ui->comboBox_year->currentText().toInt();

    QString completeDate = QString("%1-%2-%3").arg(year, 4).arg(month, 2, 10, QLatin1Char('0')).arg(day, 2, 10, QLatin1Char('0'));


    if (!conn.connOpen()){
        qDebug() << "Failed to open the database";
        return;
    }

    conn.connOpen();


    if (password != confirmPassword) {
           ui->label_signup->setText("Passwords do not match.");
           return;
       }
    if (password.length() < 8 || !hasNumericcase(password) || !hasUppercase(password) || !hasLowercase(password)) {
            ui->label_signup->setText("Password must be at least 8 characters long and include at least one lowercase letter, one uppercase letter, and one numeric digit.");
            return;
    }

    QSqlQuery qry;
    qry.prepare("insert into table_userinfo (username,password,conpassword,Mobile,Gender,Address,DOB,Country) values ('"+username+"','"+password+"','"+confirmPassword+"','"+mobile+"','"+gender+"','"+address+"','"+completeDate+"','"+Country+"')");

    if (qry.exec())
    {
        QMessageBox::critical(this,tr("Save"),tr("Saved"));
        conn.connClose();
        this->hide();

        MainWindow *mainwindow;
        mainwindow = new MainWindow(this);
        mainwindow->show();
    }
    else
    {
        QMessageBox::critical(this,tr("error::"),qry.lastError().text());
    }

}

void Dialog::on_radioButton_male_clicked()
{
    gender = "Male";
}


void Dialog::on_radioButton_female_clicked()
{
    gender = "Female";
}


void Dialog::on_radioButton_transmale_clicked()
{
    gender = "Other";
}


void Dialog::on_comboBox_country_activated(int index)
{
    Country = ui->comboBox_country->itemText(index);
}

